package com.santoshdev.notnote;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "notes_db";
    // Version 2 se 3 kar diya taaki page_color add ho sake
    private static final int DATABASE_VERSION = 3; 

    private static final String TABLE_NOTES = "notes";
    private static final String COL_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_CONTENT = "content";
    private static final String COL_TIMESTAMP = "timestamp";
    private static final String COL_IS_PRIVATE = "is_private";
    // Naya column color save karne ke liye
    private static final String COL_PAGE_COLOR = "page_color"; 

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NOTES + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TITLE + " TEXT, " +
                COL_CONTENT + " TEXT, " +
                COL_TIMESTAMP + " INTEGER, " +
                COL_IS_PRIVATE + " INTEGER DEFAULT 0, " +
                COL_PAGE_COLOR + " TEXT DEFAULT '#FFFFFF')"; // Default color white
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_NOTES + " ADD COLUMN " + COL_IS_PRIVATE + " INTEGER DEFAULT 0");
        }
        // Agar version 3 se kam hai, toh naya page_color column add kar do
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE " + TABLE_NOTES + " ADD COLUMN " + COL_PAGE_COLOR + " TEXT DEFAULT '#FFFFFF'");
        }
    }

    public long insertNote(String title, String content, String pageColor) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, title);
        values.put(COL_CONTENT, content);
        values.put(COL_TIMESTAMP, System.currentTimeMillis());
        values.put(COL_IS_PRIVATE, 0); 
        values.put(COL_PAGE_COLOR, pageColor != null ? pageColor : "#FFFFFF");
        return db.insert(TABLE_NOTES, null, values);
    }

    public int updateNote(int id, String title, String content, String pageColor) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, title);
        values.put(COL_CONTENT, content);
        values.put(COL_TIMESTAMP, System.currentTimeMillis());
        values.put(COL_PAGE_COLOR, pageColor != null ? pageColor : "#FFFFFF");
        return db.update(TABLE_NOTES, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteNote(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NOTES, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NOTES + " WHERE " + COL_IS_PRIVATE + " = 0 ORDER BY " + COL_TIMESTAMP + " DESC", null);
        
        if (cursor.moveToFirst()) {
            do {
                boolean isPrivate = cursor.getInt(4) == 1;
                String pageColor = cursor.getString(5); // Index 5 par page_color hai
                if (pageColor == null) pageColor = "#FFFFFF";

                notes.add(new Note(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getLong(3),
                        isPrivate,
                        pageColor
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return notes;
    }

    public List<Note> getPrivateNotes() {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NOTES + " WHERE " + COL_IS_PRIVATE + " = 1 ORDER BY " + COL_TIMESTAMP + " DESC", null);
        
        if (cursor.moveToFirst()) {
            do {
                boolean isPrivate = cursor.getInt(4) == 1;
                String pageColor = cursor.getString(5);
                if (pageColor == null) pageColor = "#FFFFFF";

                notes.add(new Note(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getLong(3),
                        isPrivate,
                        pageColor
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return notes;
    }

    public void updateNotePrivacy(int id, boolean isPrivate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_IS_PRIVATE, isPrivate ? 1 : 0);
        db.update(TABLE_NOTES, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }
}
