package com.santoshdev.notnote;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class EditorActivity extends Activity {
    private EditText etTitle;
    private WebView webViewEditor;
    private TextView tvWordCount, tvEditorStatus;
    private LinearLayout colorPaletteContainer, layoutAiToolsContainer;
    private View bottomToolsContainer, sidebarColorMenu;
    private DatabaseHelper dbHelper;
    private int noteId = -1;
    private static final int PICK_IMAGE_REQUEST = 1001;
    
    private String currentEditorHtml = "";
    private String currentPageColor = "#FFFFFF"; 
    private boolean hasUnsavedChanges = false;
    private boolean isWebViewLoaded = false;
    private String pendingHtmlToLoad = "";

    private ImageView btnAiAction, btnCloseAi, btnAiSend, btnFillColor;
    private EditText etAiInput;

    private EditorHelper editorHelper;
    private SharedPreferences aiPrefs;
    private List<ColorOption> colorOptionsList;

    private int sidebarWidthPx;
    private boolean wasKeyboardOpen = false; 

    @Override 
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        
        dbHelper = new DatabaseHelper(this);
        aiPrefs = getSharedPreferences("NotNoteAiPrefs", MODE_PRIVATE);
        
        etTitle = findViewById(R.id.et_title);
        webViewEditor = findViewById(R.id.editor_webview);
        tvWordCount = findViewById(R.id.tv_word_count);
        bottomToolsContainer = findViewById(R.id.bottom_tools_container);
        colorPaletteContainer = findViewById(R.id.color_palette_container);
        layoutAiToolsContainer = findViewById(R.id.layout_ai_tools_container);
        sidebarColorMenu = findViewById(R.id.sidebar_color_menu);
        
        sidebarWidthPx = dp(310);

        try { tvEditorStatus = findViewById(R.id.tv_editor_status); } catch (Exception e) { tvEditorStatus = null; }
        
        editorHelper = new EditorHelper(this, webViewEditor);

        setupWebView();
        setupToolbar();
        setupAiToolbar();
        setupKeyboardListener();
        setupColorSidebar();

        loadExistingNote();

        etTitle.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                markAsUnsaved(); 
            }
        });
    }

    private void showSidebar() {
        if (sidebarColorMenu != null && sidebarColorMenu.getVisibility() != View.VISIBLE) {
            hideKeyboard();
            sidebarColorMenu.setTranslationX(sidebarWidthPx);
            sidebarColorMenu.setVisibility(View.VISIBLE);
            sidebarColorMenu.animate()
                    .translationX(0)
                    .setDuration(250)
                    .start();

            if (colorPaletteContainer != null) colorPaletteContainer.setVisibility(View.GONE);
            if (layoutAiToolsContainer != null) {
                layoutAiToolsContainer.setVisibility(View.GONE);
                btnCloseAi.setVisibility(View.GONE);
                btnAiAction.setVisibility(View.VISIBLE);
            }
        }
    }

    private void hideSidebar() {
        if (sidebarColorMenu != null && sidebarColorMenu.getVisibility() == View.VISIBLE) {
            sidebarColorMenu.animate()
                    .translationX(sidebarWidthPx)
                    .setDuration(250)
                    .withEndAction(() -> sidebarColorMenu.setVisibility(View.GONE))
                    .start();
        }
    }

    private void setupKeyboardListener() {
        View rootView = findViewById(android.R.id.content);
        rootView.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect r = new Rect();
            rootView.getWindowVisibleDisplayFrame(r);
            int screenHeight = rootView.getRootView().getHeight();
            int keypadHeight = screenHeight - r.bottom;

            boolean isKeyboardOpen = keypadHeight > screenHeight * 0.15;

            if (isKeyboardOpen) {
                if (bottomToolsContainer != null && bottomToolsContainer.getVisibility() != View.VISIBLE) {
                    bottomToolsContainer.setVisibility(View.VISIBLE);
                }
                
                if (!wasKeyboardOpen && sidebarColorMenu != null && sidebarColorMenu.getVisibility() == View.VISIBLE) {
                    sidebarColorMenu.setVisibility(View.GONE);
                }
            } else {
                boolean isAiOpen = layoutAiToolsContainer != null && layoutAiToolsContainer.getVisibility() == View.VISIBLE;
                
                if (bottomToolsContainer != null && bottomToolsContainer.getVisibility() == View.VISIBLE && !isAiOpen) {
                    bottomToolsContainer.setVisibility(View.GONE);
                }
            }
            
            wasKeyboardOpen = isKeyboardOpen;
        });
    }

    private class ColorOption {
        int viewId; String hex; String shape;
        ColorOption(int viewId, String hex, String shape) {
            this.viewId = viewId; this.hex = hex; this.shape = shape;
        }
    }

    private int dp(float value){ return Math.round(value*getResources().getDisplayMetrics().density); }

    private void setupColorSidebar() {
        colorOptionsList = new ArrayList<>();
        colorOptionsList.add(new ColorOption(R.id.color_white, "#FFFFFF", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_ef9a9a, "#EF9A9A", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_e57373, "#E57373", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_b71c1c, "#B71C1C", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_f06292, "#F06292", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_ce93d8, "#CE93D8", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_e1bee7, "#E1BEE7", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_b39ddb, "#B39DDB", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_d1c4e9, "#D1C4E9", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_9fa8da, "#9FA8DA", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_c5cae9, "#C5CAE9", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_b2ebf2, "#B2EBF2", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_80cbc4, "#80CBC4", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_b2dfdb, "#B2DFDB", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_a5d6a7, "#A5D6A7", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_c8e6c9, "#C8E6C9", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_f9fbe7, "#F9FBE7", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_ffe0b2, "#FFE0B2", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_d7ccc8, "#D7CCC8", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_bcaaa4, "#BCAAA4", "CIRCLE"));
        colorOptionsList.add(new ColorOption(R.id.color_f0f4c3, "#F0F4C3", "CIRCLE"));

        for (ColorOption option : colorOptionsList) {
            View itemView = findViewById(option.viewId);
            if (itemView == null) continue;
            
            CardView cardShape = itemView.findViewById(R.id.color_shape);
            cardShape.setCardBackgroundColor(Color.parseColor(option.hex));
            
            cardShape.setOnClickListener(v -> {
                currentPageColor = option.hex;
                applyPageColor(currentPageColor);
                markAsUnsaved();
                hideKeyboard();
            });
        }
    }

    private void applyPageColor(String hexColor) {
        findViewById(R.id.root_layout).setBackgroundColor(Color.parseColor(hexColor));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(hexColor));
            
            View decor = window.getDecorView();
            int flags = decor.getSystemUiVisibility();
            if (isColorLight(Color.parseColor(hexColor))) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            decor.setSystemUiVisibility(flags);
        }

        for (ColorOption option : colorOptionsList) {
            View itemView = findViewById(option.viewId);
            if (itemView != null) {
                FrameLayout checkContainer = itemView.findViewById(R.id.check_container);
                if (option.hex.equalsIgnoreCase(hexColor)) {
                    checkContainer.setVisibility(View.VISIBLE);
                } else {
                    checkContainer.setVisibility(View.GONE);
                }
            }
        }
    }

    private boolean isColorLight(int color) {
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
        return darkness < 0.5;
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        WebSettings settings = webViewEditor.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        
        webViewEditor.setBackgroundColor(Color.TRANSPARENT);
        webViewEditor.setWebChromeClient(new WebChromeClient());
        webViewEditor.addJavascriptInterface(new WebAppInterface(), "Android");
        
        webViewEditor.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                isWebViewLoaded = true;
                if (!pendingHtmlToLoad.isEmpty()) {
                    loadHtmlIntoEditor(pendingHtmlToLoad);
                    pendingHtmlToLoad = "";
                }
            }
        });

        webViewEditor.loadUrl("file:///android_asset/rich_editor.html");
    }

    private class WebAppInterface {
        @JavascriptInterface
        public void onTextChanged(final String html, final String text) {
            runOnUiThread(() -> {
                hasUnsavedChanges = true;
                updateEditorStatus("Unsaved changes");
                
                if (html != null) {
                    currentEditorHtml = html;
                }
                
                int count = 0;
                if (text != null && !text.trim().isEmpty()) {
                    count = text.trim().split("\\s+").length;
                }
                
                if (tvWordCount != null) {
                    tvWordCount.setText(count + " " + (count == 1 ? "word" : "words"));
                }
            });
        }

        // YE NAYA FUNCTION HAI JO BACK BUTTON DABANE PAR LATEST HTML FETCH KARTA HAI
        @JavascriptInterface
        public void saveNoteAndClose(final String html) {
            runOnUiThread(() -> {
                if (html != null) {
                    currentEditorHtml = html;
                }
                saveNote();
                finish();
            });
        }
    }

    private void execJs(String jsCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webViewEditor.evaluateJavascript("javascript:" + jsCode, null);
        } else {
            webViewEditor.loadUrl("javascript:" + jsCode);
        }
    }

    private void loadHtmlIntoEditor(String html) {
        if (html == null) html = "";
        try {
            String encodedBase64 = Base64.encodeToString(html.getBytes("UTF-8"), Base64.NO_WRAP);
            execJs("setHtmlFromBase64('" + encodedBase64 + "');");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadExistingNote() {
        if (getIntent() == null) return;
        noteId = getIntent().getIntExtra("note_id", -1);
        String title = getIntent().getStringExtra("note_title");
        String content = getIntent().getStringExtra("note_content");
        currentPageColor = getIntent().getStringExtra("note_color"); 
        
        if (title != null) etTitle.setText(title);
        
        if (content != null) {
            currentEditorHtml = content;
            if (isWebViewLoaded) {
                loadHtmlIntoEditor(content);
            } else {
                pendingHtmlToLoad = content; 
            }
        }
        
        if (currentPageColor == null || currentPageColor.isEmpty()) {
            currentPageColor = "#FFFFFF";
        }
        applyPageColor(currentPageColor);
        hasUnsavedChanges = false;
    }

    // NAYA METHOD: Force sync before exit
    private void saveAndExit() {
        if (isWebViewLoaded) {
            execJs("if(window.Android) window.Android.saveNoteAndClose(document.querySelector('[contenteditable=true]') ? document.querySelector('[contenteditable=true]').innerHTML : document.body.innerHTML);");
        } else {
            saveNote();
            finish();
        }
    }

    // BACK BUTTON AUR GESTURE PAR BHI SAVE AND EXIT CHALEGA
    @Override
    public void onBackPressed() {
        saveAndExit();
    }

    private void setupToolbar() {
        // Toolbar ke back button ko bhi update kar diya
        findViewById(R.id.btn_back).setOnClickListener(v -> saveAndExit());
        
        btnFillColor = findViewById(R.id.btn_fill_color);
        btnFillColor.setOnClickListener(v -> {
            if (sidebarColorMenu != null) {
                if (sidebarColorMenu.getVisibility() == View.VISIBLE) {
                    hideSidebar();
                } else {
                    showSidebar();
                }
            }
        });
        
        findViewById(R.id.btn_undo).setOnClickListener(v -> { execJs("formatDoc('undo')"); markAsUnsaved(); });
        findViewById(R.id.btn_redo).setOnClickListener(v -> { execJs("formatDoc('redo')"); markAsUnsaved(); });
        findViewById(R.id.btn_bold).setOnClickListener(v -> { execJs("formatDoc('bold')"); markAsUnsaved(); });
        findViewById(R.id.btn_italic).setOnClickListener(v -> { execJs("formatDoc('italic')"); markAsUnsaved(); });
        findViewById(R.id.btn_underline).setOnClickListener(v -> { execJs("formatDoc('underline')"); markAsUnsaved(); });
        findViewById(R.id.btn_strike).setOnClickListener(v -> { execJs("formatDoc('strikeThrough')"); markAsUnsaved(); });
        findViewById(R.id.btn_h1).setOnClickListener(v -> { execJs("toggleHeading('H1')"); markAsUnsaved(); });
        findViewById(R.id.btn_h2).setOnClickListener(v -> { execJs("toggleHeading('H2')"); markAsUnsaved(); });
        findViewById(R.id.btn_h3).setOnClickListener(v -> { execJs("toggleHeading('H3')"); markAsUnsaved(); });
        findViewById(R.id.btn_h4).setOnClickListener(v -> { execJs("toggleHeading('H4')"); markAsUnsaved(); });
        findViewById(R.id.btn_h5).setOnClickListener(v -> { execJs("toggleHeading('H5')"); markAsUnsaved(); });
        findViewById(R.id.btn_h6).setOnClickListener(v -> { execJs("toggleHeading('H6')"); markAsUnsaved(); });
        findViewById(R.id.btn_number).setOnClickListener(v -> { execJs("formatDoc('insertOrderedList')"); markAsUnsaved(); });
        findViewById(R.id.btn_bullet).setOnClickListener(v -> { execJs("formatDoc('insertUnorderedList')"); markAsUnsaved(); }); 
        findViewById(R.id.btn_check).setOnClickListener(v -> { execJs("insertCheckbox()"); markAsUnsaved(); });
        findViewById(R.id.btn_link).setOnClickListener(v -> insertLink());
        findViewById(R.id.btn_image).setOnClickListener(v -> openGallery());

        View btnHighlight = findViewById(R.id.btn_highlight);
        btnHighlight.setOnClickListener(v -> { execJs("toggleHighlight('#FFE58A')"); markAsUnsaved(); }); 
        btnHighlight.setOnLongClickListener(v -> {
            if (colorPaletteContainer != null) colorPaletteContainer.setVisibility(colorPaletteContainer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            if (layoutAiToolsContainer != null) {
                layoutAiToolsContainer.setVisibility(View.GONE);
                btnCloseAi.setVisibility(View.GONE);
                btnAiAction.setVisibility(View.VISIBLE);
            }
            hideSidebar();
            return true;
        });

        String[] hexColors = {"#FFE58A", "#A5FF8A", "#8AE8FF", "#FF8A8A", "#E58AFF", "#DDDDDD"};
        int[] ids = {R.id.color_yellow, R.id.color_green, R.id.color_cyan, R.id.color_red, R.id.color_magenta, R.id.color_grey};
        for (int i = 0; i < ids.length; i++) {
            final String hex = hexColors[i];
            View v = findViewById(ids[i]);
            if(v != null) v.setOnClickListener(view -> { 
                execJs("toggleHighlight('" + hex + "')"); 
                markAsUnsaved();
                colorPaletteContainer.setVisibility(View.GONE); 
            });
        }
    }

    private void insertLink() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_insert_link);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setGravity(Gravity.BOTTOM);

        EditText etLinkInput = dialog.findViewById(R.id.et_link_input);
        View btnCancel = dialog.findViewById(R.id.btn_cancel_link);
        View btnInsert = dialog.findViewById(R.id.btn_insert_link);

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnInsert.setOnClickListener(v -> {
            String url = etLinkInput.getText().toString().trim();
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            
            execJs("formatDoc('createLink', '" + url + "')");
            markAsUnsaved();
            dialog.dismiss();
        });
        dialog.show();
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        try { startActivityForResult(intent, PICK_IMAGE_REQUEST); }
        catch(Exception e){ 
            Intent fallback = new Intent(Intent.ACTION_GET_CONTENT); 
            fallback.setType("image/*"); 
            startActivityForResult(fallback, PICK_IMAGE_REQUEST); 
        }
    }

    @Override 
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode != PICK_IMAGE_REQUEST || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        insertImage(data.getData());
    }

    private String copyImageToInternalStorage(Uri uri) throws Exception {
        File dir = new File(getFilesDir(),"note_images");
        if(!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create image directory");
        File target = new File(dir, "img_" + System.currentTimeMillis() + ".png");
        InputStream in = null; FileOutputStream out = null;
        try{
            in = getContentResolver().openInputStream(uri); if(in == null) throw new Exception("Unable to read image");
            out = new FileOutputStream(target); byte[] buffer = new byte[8192]; int n;
            while((n = in.read(buffer)) != -1) out.write(buffer, 0, n); 
            out.flush(); return target.getAbsolutePath();
        }finally{
            if(in != null) try{in.close();} catch(Exception ignored){}
            if(out != null) try{out.close();} catch(Exception ignored){}
        }
    }

    private void insertImage(Uri uri) {
        try{
            String path = copyImageToInternalStorage(uri);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, options);
            
            int width = options.outWidth;
            int height = options.outHeight;
            
            int maxWidth = getResources().getDisplayMetrics().widthPixels - dp(48);
            if(width > maxWidth){ 
                float ratio = maxWidth / (float) width; 
                width = maxWidth; 
                height = Math.round(height * ratio); 
            }
            
            execJs("insertImage('" + path + "', " + width + ", " + height + ")");
            markAsUnsaved();
        }catch(Exception e){
            Toast.makeText(this,"Unable to add image",Toast.LENGTH_SHORT).show();
        }
    }

    private void setupAiToolbar() {
        btnAiAction = findViewById(R.id.btn_ai_action);
        btnCloseAi = findViewById(R.id.btn_close_ai);
        btnAiSend = findViewById(R.id.btn_ai_send);
        etAiInput = findViewById(R.id.et_ai_input);

        btnAiSend.setEnabled(false);
        btnAiSend.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E0E0E0")));
        btnAiSend.setColorFilter(Color.parseColor("#888888"));

        etAiInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString().trim();
                if (text.isEmpty()) {
                    btnAiSend.setEnabled(false);
                    btnAiSend.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E0E0E0")));
                    btnAiSend.setColorFilter(Color.parseColor("#888888"));
                } else {
                    btnAiSend.setEnabled(true);
                    btnAiSend.setBackgroundTintList(ColorStateList.valueOf(Color.BLACK));
                    btnAiSend.setColorFilter(Color.WHITE);
                }
            }
        });

        btnAiAction.setOnClickListener(v -> {
            layoutAiToolsContainer.setVisibility(View.VISIBLE);
            btnAiAction.setVisibility(View.GONE);
            btnCloseAi.setVisibility(View.VISIBLE);
            if (colorPaletteContainer != null) colorPaletteContainer.setVisibility(View.GONE);
            hideSidebar();
        });

        btnCloseAi.setOnClickListener(v -> {
            layoutAiToolsContainer.setVisibility(View.GONE);
            btnCloseAi.setVisibility(View.GONE);
            btnAiAction.setVisibility(View.VISIBLE);
        });

        btnAiSend.setOnClickListener(v -> {
            String customPrompt = etAiInput.getText().toString().trim();
            if (!customPrompt.isEmpty()) {
                executeAiCommand(customPrompt);
                etAiInput.setText(""); 
                hideKeyboard();
            }
        });
    }

    private void executeAiCommand(String command) {
        String title = etTitle.getText().toString().trim();
        String plainContent = Html.fromHtml(currentEditorHtml).toString().trim();
        String contextText = "Title: " + title + "\n\nContent:\n" + plainContent;

        if (plainContent.isEmpty()) {
            contextText = "[The note is currently empty. User is asking you to write something new.]";
        }

        final String finalContextText = contextText;
        String provider = aiPrefs.getString("selected_provider", "");
        
        if (provider.isEmpty()) {
            Toast.makeText(this, "Please configure AI in Settings first.", Toast.LENGTH_LONG).show();
            return;
        }

        if (tvEditorStatus != null) tvEditorStatus.setText("AI is thinking...");
        if (layoutAiToolsContainer != null) layoutAiToolsContainer.setVisibility(View.GONE);
        if (btnCloseAi != null) {
            btnCloseAi.setVisibility(View.GONE);
            btnAiAction.setVisibility(View.VISIBLE);
        }

        new Thread(() -> {
            try {
                String response;
                if (provider.equals("gemini")) {
                    String encryptedKey = aiPrefs.getString("encrypted_api_key_gemini", "");
                    String apiKey = SecurityHelper.decrypt(encryptedKey);
                    String model = aiPrefs.getString("selected_model_gemini", "gemini-1.5-flash");
                    response = AiApiManager.callGeminiForEditor(apiKey, model, finalContextText, command);
                } else {
                    String encryptedKey = aiPrefs.getString("encrypted_api_key_cf", "");
                    String apiKey = SecurityHelper.decrypt(encryptedKey);
                    String accountId = aiPrefs.getString("cf_account_id", "");
                    String model = aiPrefs.getString("selected_model_cf", "@cf/meta/llama-3.2-3b-instruct");
                    response = AiApiManager.callCloudflareForEditor(apiKey, accountId, model, finalContextText, command);
                }

                runOnUiThread(() -> {
                    try {
                        editorHelper.processAiResponse(response);
                    } catch (Exception ex) {
                        Toast.makeText(EditorActivity.this, "UI Processing Error", Toast.LENGTH_SHORT).show();
                    } finally {
                        if (tvEditorStatus != null) tvEditorStatus.setText("Editing Note");
                    }
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (tvEditorStatus != null) tvEditorStatus.setText("Editing Note");
                    Toast.makeText(EditorActivity.this, "AI Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }
    
    private void updateEditorStatus(String status){if(tvEditorStatus!=null)tvEditorStatus.setText(status);}

    public void markAsUnsaved() {
        runOnUiThread(() -> {
            hasUnsavedChanges = true;
            updateEditorStatus("Unsaved changes");
        });
    }

    private void saveNote() {
        if (!hasUnsavedChanges && noteId != -1) return; 
        
        String title = etTitle.getText().toString().trim();
        String html = currentEditorHtml;
        
        if(title.isEmpty() && (html.isEmpty() || html.equals("<br>"))) return;
        
        if(noteId == -1) {
            long id = dbHelper.insertNote(title, html, currentPageColor);
            if(id > 0) { noteId = (int)id; hasUnsavedChanges = false; }
        } else {
            dbHelper.updateNote(noteId, title, html, currentPageColor);
            hasUnsavedChanges = false;
        }
        updateEditorStatus("Saved");
    }

    @Override protected void onPause() { saveNote(); super.onPause(); }
}
