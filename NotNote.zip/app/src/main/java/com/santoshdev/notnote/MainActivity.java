package com.santoshdev.notnote;

import android.app.Activity;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.Html;
import android.text.Layout;
import android.text.Spanned;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements NotesAdapter.NoteActionListener {

    private RecyclerView recyclerNotes;
    private FrameLayout btnAddNote;
    private View btnSettings; 
    private EditText etSearch;
    private ImageView btnViewList, btnViewGrid;
    
    private LinearLayout searchCard, toggleContainer, emptyStateContainer, emptySearchContainer;
    
    private NotesAdapter adapter;
    private List<Note> allNotes;
    private DatabaseHelper dbHelper;
    private boolean isGridView = false; 
    
    private SharedPreferences prefs; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        dbHelper = new DatabaseHelper(this);
        allNotes = new ArrayList<>();

        prefs = getSharedPreferences("NotNotePrefs", MODE_PRIVATE);
        isGridView = prefs.getBoolean("isGridView", false);

        recyclerNotes = findViewById(R.id.recycler_notes);
        btnAddNote = findViewById(R.id.btn_add_note);
        btnSettings = findViewById(R.id.btn_settings); 
        etSearch = findViewById(R.id.et_search);
        btnViewList = findViewById(R.id.btn_view_list);
        btnViewGrid = findViewById(R.id.btn_view_grid);
        
        searchCard = findViewById(R.id.search_card);
        toggleContainer = findViewById(R.id.toggle_container);
        
        emptyStateContainer = findViewById(R.id.empty_state_container);
        emptySearchContainer = findViewById(R.id.empty_search_container);

        adapter = new NotesAdapter(this, this);
        adapter.setHasStableIds(true); 
        recyclerNotes.setAdapter(adapter);

        setupRecyclerViewLayout();
        setupClickListeners();
    }

    private void setupRecyclerViewLayout() {
        if (isGridView) {
            StaggeredGridLayoutManager staggeredManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
            staggeredManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
            recyclerNotes.setLayoutManager(staggeredManager);
            
            btnViewGrid.setBackgroundResource(R.drawable.bg_toggle_selection);
            btnViewList.setBackgroundResource(0);
        } else {
            LinearLayoutManager linearManager = new LinearLayoutManager(this);
            recyclerNotes.setLayoutManager(linearManager);
            
            btnViewList.setBackgroundResource(R.drawable.bg_toggle_selection);
            btnViewGrid.setBackgroundResource(0);
        }
        
        recyclerNotes.setItemAnimator(null);
        if (adapter != null) {
            adapter.setGridView(isGridView);
        }
    }

    private void setupClickListeners() {
        btnAddNote.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, EditorActivity.class));
        });

        btnSettings.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterNotes(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnViewList.setOnClickListener(v -> {
            if (isGridView) {
                isGridView = false;
                prefs.edit().putBoolean("isGridView", false).apply(); 
                setupRecyclerViewLayout();
            }
        });

        btnViewGrid.setOnClickListener(v -> {
            if (!isGridView) {
                isGridView = true;
                prefs.edit().putBoolean("isGridView", true).apply(); 
                setupRecyclerViewLayout();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.clearMetadataCache(); 
        }
        allNotes.clear();
        allNotes.addAll(dbHelper.getAllNotes());
        filterNotes(etSearch.getText().toString());
    }

    public void filterNotes(String query) {
        List<Note> filteredNotes = new ArrayList<>();
        if (query.trim().isEmpty()) {
            filteredNotes.addAll(allNotes);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (Note note : allNotes) {
                String content = note.getContent() != null ? note.getContent() : "";
                String cleanContent = "";
                if (Build.VERSION.SDK_INT >= 24) {
                    cleanContent = Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY).toString().toLowerCase();
                } else {
                    cleanContent = Html.fromHtml(content).toString().toLowerCase();
                }
                
                if (note.getTitle().toLowerCase().contains(lowerCaseQuery) || cleanContent.contains(lowerCaseQuery)) {
                    filteredNotes.add(note);
                }
            }
        }
        
        adapter.updateList(filteredNotes);
        updateUIState(filteredNotes.size());
    }

    private void updateUIState(int listSize) {
        if (allNotes.isEmpty()) {
            searchCard.setVisibility(View.GONE);
            toggleContainer.setVisibility(View.GONE);
            
            emptyStateContainer.setVisibility(View.VISIBLE);
            emptySearchContainer.setVisibility(View.GONE);
            recyclerNotes.setVisibility(View.GONE);
        } else {
            searchCard.setVisibility(View.VISIBLE);
            toggleContainer.setVisibility(View.VISIBLE);
            emptyStateContainer.setVisibility(View.GONE);
            
            if (listSize == 0) {
                recyclerNotes.setVisibility(View.GONE);
                emptySearchContainer.setVisibility(View.VISIBLE);
            } else {
                recyclerNotes.setVisibility(View.VISIBLE);
                emptySearchContainer.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onNoteClick(Note note) {
        Intent intent = new Intent(MainActivity.this, EditorActivity.class);
        intent.putExtra("note_id", note.getId());
        intent.putExtra("note_title", note.getTitle());
        intent.putExtra("note_content", note.getContent());
        intent.putExtra("note_color", note.getPageColor()); 
        startActivity(intent);
    }

    @Override
    public void onNotesShare(List<Note> notes) {
        if (notes != null && !notes.isEmpty()) {
            if (notes.size() > 1) {
                Toast.makeText(this, "Sharing the first selected note...", Toast.LENGTH_SHORT).show();
            }
            openShareDialog(notes.get(0));
        }
    }

    @Override
    public void onNotesDelete(List<Note> notes) {
        if (notes != null && !notes.isEmpty()) {
            for (Note note : notes) {
                dbHelper.deleteNote(note.getId());
                allNotes.remove(note);
            }
            filterNotes(etSearch.getText().toString());
            Toast.makeText(this, notes.size() + " Note(s) deleted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onNotesPrivate(List<Note> notes) {
        if (notes != null && !notes.isEmpty()) {
            for (Note note : notes) {
                dbHelper.updateNotePrivacy(note.getId(), true);
                allNotes.remove(note);
            }
            filterNotes(etSearch.getText().toString());
            Toast.makeText(this, notes.size() + " Note(s) moved to Private Vault", Toast.LENGTH_SHORT).show();
        }
    }

    // Yahan Material BottomSheetDialog ko normal Dialog se replace kar diya gaya hai
    private void openShareDialog(Note note) {
        final Dialog shareBottomSheet = new Dialog(MainActivity.this);
        shareBottomSheet.setContentView(R.layout.dialog_share_note);
        
        // Dialog ko bottom mein set karne aur transparent background dene ke liye
        if (shareBottomSheet.getWindow() != null) {
            shareBottomSheet.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            shareBottomSheet.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            shareBottomSheet.getWindow().setGravity(Gravity.BOTTOM);
        }

        shareBottomSheet.findViewById(R.id.btn_share_pdf_action).setOnClickListener(v -> {
            shareBottomSheet.dismiss();
            Toast.makeText(this, "Preparing PDF for share...", Toast.LENGTH_SHORT).show();
            processNoteForPdfOrImage(note, true, false);
        });

        shareBottomSheet.findViewById(R.id.btn_download_pdf_action).setOnClickListener(v -> {
            shareBottomSheet.dismiss();
            processNoteForPdfOrImage(note, false, false);
        });

        shareBottomSheet.findViewById(R.id.btn_share_image_action).setOnClickListener(v -> {
            shareBottomSheet.dismiss();
            Toast.makeText(this, "Generating Image...", Toast.LENGTH_SHORT).show();
            processNoteForPdfOrImage(note, true, true);
        });

        shareBottomSheet.findViewById(R.id.btn_share_text_action).setOnClickListener(v -> {
            shareBottomSheet.dismiss();
            shareNoteAsText(note);
        });

        shareBottomSheet.show();
    }

    private void shareNoteAsText(Note note) {
        String htmlContent = note.getContent();
        if (htmlContent == null) htmlContent = "";

        htmlContent = htmlContent
                .replaceAll("(?i)<span class=\"checkbox checked\"[^>]*>.*?</span>", "[✓] ")
                .replaceAll("(?i)<span class=\"checkbox\"[^>]*>.*?</span>", "[ ] ")
                .replaceAll("(?i)<b>", "<b>*")
                .replaceAll("(?i)</b>", "*</b>")
                .replaceAll("(?i)<strong>", "<strong>*")
                .replaceAll("(?i)</strong>", "*</strong>")
                .replaceAll("(?i)<i>", "<i>_")
                .replaceAll("(?i)</i>", "_</i>")
                .replaceAll("(?i)<em>", "<em>_")
                .replaceAll("(?i)</em>", "_</em>")
                .replaceAll("(?i)<strike>", "<strike>~")
                .replaceAll("(?i)</strike>", "~</strike>")
                .replaceAll("(?i)<s>", "<s>~")
                .replaceAll("(?i)</s>", "~</s>");

        Spanned cleanSpanned;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            cleanSpanned = Html.fromHtml(htmlContent, Html.FROM_HTML_MODE_LEGACY);
        } else {
            cleanSpanned = Html.fromHtml(htmlContent);
        }

        String plainText = cleanSpanned.toString().replaceAll("\uFFFC", "").replaceAll("\n{3,}", "\n\n").trim();
        String shareBody = "*" + note.getTitle().trim() + "*\n\n" + plainText;
        
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, note.getTitle());
        intent.putExtra(Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(intent, "Share Note as Text"));
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void processNoteForPdfOrImage(Note note, boolean isShare, boolean isImage) {
        int pageWidth = 800; 
        int pageHeight = 1131; 
        int margin = 60; 
        final int contentWidth = pageWidth - (2 * margin);
        final int contentHeight = pageHeight - (2 * margin); 

        TextView tv = new TextView(this);
        tv.setPadding(0, 0, 0, 0); 
        tv.setTextSize(16f);
        tv.setTextColor(Color.parseColor("#333333")); 
        tv.setLineSpacing(0, 1.3f); 
        
        String rawContent = note.getContent() != null ? note.getContent() : "";
        String titleHtml = "<h2 style='text-align:center; margin-top:0px;'><b>" + note.getTitle() + "</b></h2><br>";
        String preparedHtml = titleHtml + rawContent;

        // --- SPACING FIXES START ---
        // Bullet point aur number ke baad 2 space extra add karta hai taaki text chipke na
        preparedHtml = preparedHtml.replaceAll("•\\s*", "• &nbsp;&nbsp;");
        preparedHtml = preparedHtml.replaceAll("(\\d+\\.)\\s*([a-zA-Z])", "$1 &nbsp;&nbsp;$2");
        preparedHtml = preparedHtml.replaceAll("(?i)<li>\\s*", "<li>&nbsp;&nbsp;");
        // --- SPACING FIXES END ---

        preparedHtml = preparedHtml.replaceAll("(?i)<span[^>]*style=\"[^\"]*text-decoration\\s*:\\s*line-through[^\"]*\"[^>]*>(.*?)</span>", "<s>$1</s>");
        
        preparedHtml = preparedHtml
            .replaceAll("(?i)<span class=\"checkbox checked\"[^>]*>.*?</span>", "<img src=\"checkbox_checked\"> ")
            .replaceAll("(?i)<span class=\"checkbox\"[^>]*>.*?</span>", "<img src=\"checkbox_unchecked\"> ")
            .replaceAll("<svg[^>]*>.*?</svg>", "<img src=\"checkbox_unchecked\"> ")
            .replaceAll("☑", "<img src=\"checkbox_checked\"> ")
            .replaceAll("☐", "<img src=\"checkbox_unchecked\"> ");

        Html.ImageGetter imageGetter = source -> {
            try {
                String path = source;
                int targetW = -1;
                int targetH = -1;

                int sep = path.indexOf("|w=");
                if (sep >= 0) {
                    try {
                        String[] parts = path.substring(sep + 1).split("\\|");
                        for (String part : parts) {
                            String numStr = part.substring(2).replaceAll("[^0-9.]", "");
                            if (part.startsWith("w=")) targetW = (int) Float.parseFloat(numStr);
                            if (part.startsWith("h=")) targetH = (int) Float.parseFloat(numStr);
                        }
                    } catch (Exception ignored) {}
                    path = path.substring(0, sep);
                }

                if (path.startsWith("file://")) path = path.substring(7);

                Drawable d = null;
                if (path.equals("tick_icon")) {
                    d = getResources().getDrawable(R.drawable.ic_tick);
                    d.setBounds(0, 0, 40, 40); 
                    return d;
                } else if (path.equals("checkbox_checked")) {
                    d = getResources().getDrawable(android.R.drawable.checkbox_on_background);
                    if (d != null) d.setBounds(0, 0, dpToPx(18), dpToPx(18));
                    return d;
                } else if (path.equals("checkbox_unchecked")) {
                    d = getResources().getDrawable(android.R.drawable.checkbox_off_background);
                    if (d != null) d.setBounds(0, 0, dpToPx(18), dpToPx(18));
                    return d;
                }

                Bitmap bitmap = BitmapFactory.decodeFile(path);
                if (bitmap != null) {
                    int w = bitmap.getWidth();
                    int h = bitmap.getHeight();

                    if (targetW > 0) {
                        float ratio = (float) h / w;
                        w = targetW;
                        h = targetH > 0 ? targetH : Math.round(targetW * ratio);
                    } else {
                        float maxImgWidth = contentWidth; 
                        float maxImgHeight = contentHeight * 0.45f;
                        float widthRatio = maxImgWidth / w;
                        float heightRatio = maxImgHeight / h;
                        float scale = Math.min(widthRatio, heightRatio);
                        if (scale > 1.2f) scale = 1.2f; 
                        w = Math.round(w * scale);
                        h = Math.round(h * scale);
                    }

                    if (w > contentWidth) {
                        float scale = (float) contentWidth / w;
                        w = Math.round(w * scale);
                        h = Math.round(h * scale);
                    }

                    if (w <= 0) w = 1;
                    if (h <= 0) h = 1;

                    Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, w, h, true);

                    int finalWidth = contentWidth; 
                    int finalHeight = h;

                    Bitmap finalBitmap = Bitmap.createBitmap(finalWidth, finalHeight, Bitmap.Config.ARGB_8888);
                    Canvas bCanvas = new Canvas(finalBitmap);
                    bCanvas.drawColor(Color.TRANSPARENT); 
                    
                    int leftOffset = (finalWidth - w) / 2;
                    
                    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    BitmapShader shader = new BitmapShader(scaledBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                    Matrix matrix = new Matrix();
                    matrix.setTranslate(leftOffset, 0);
                    shader.setLocalMatrix(matrix);
                    paint.setShader(shader);

                    RectF rect = new RectF(leftOffset, 0, leftOffset + w, h);
                    bCanvas.drawRoundRect(rect, 16, 16, paint);

                    BitmapDrawable bd = new BitmapDrawable(getResources(), finalBitmap);
                    bd.setBounds(0, 0, finalWidth, finalHeight); 
                    return bd;
                }
                return d;
            } catch (Exception e) { return null; }
        };

        Spanned spanned;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            spanned = Html.fromHtml(preparedHtml, Html.FROM_HTML_MODE_LEGACY, imageGetter, null);
        } else {
            spanned = Html.fromHtml(preparedHtml, imageGetter, null);
        }

        SpannableStringBuilder ssb = new SpannableStringBuilder(spanned);
        
        URLSpan[] urls = ssb.getSpans(0, ssb.length(), URLSpan.class);
        for (URLSpan span : urls) ssb.removeSpan(span);
        
        UnderlineSpan[] underlines = ssb.getSpans(0, ssb.length(), UnderlineSpan.class);
        for (UnderlineSpan span : underlines) ssb.removeSpan(span);

        ForegroundColorSpan[] colorSpans = ssb.getSpans(0, ssb.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan span : colorSpans) {
            int color = span.getForegroundColor();
            if (color == Color.YELLOW || (Color.red(color) > 200 && Color.green(color) > 200 && Color.blue(color) < 150)) {
                int start = ssb.getSpanStart(span);
                int end = ssb.getSpanEnd(span);
                ssb.removeSpan(span);
                ssb.setSpan(new BackgroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                ssb.setSpan(new ForegroundColorSpan(Color.BLACK), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        ssb.append("\n\n\n");
        int footerStart = ssb.length();
        ssb.append("  Created with NotNote"); 

        ssb.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), footerStart, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ssb.setSpan(new ForegroundColorSpan(Color.parseColor("#999999")), footerStart, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ssb.setSpan(new StyleSpan(Typeface.BOLD), footerStart, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ssb.setSpan(new RelativeSizeSpan(0.85f), footerStart, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        try {
            Drawable icon;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                icon = getResources().getDrawable(R.drawable.ic_ink, null);
            } else {
                icon = getResources().getDrawable(R.drawable.ic_ink);
            }
            if (icon != null) {
                icon.mutate();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    icon.setTint(Color.parseColor("#999999")); 
                }
                int iconSize = (int) (tv.getTextSize() * 1.3f); 
                icon.setBounds(0, 0, iconSize, iconSize);
                ssb.setSpan(new ImageSpan(icon, ImageSpan.ALIGN_BOTTOM), footerStart, footerStart + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        } catch (Exception e) {}

        tv.setText(ssb);

        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(contentWidth, View.MeasureSpec.EXACTLY);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        
        tv.measure(widthMeasureSpec, heightMeasureSpec);
        tv.layout(0, 0, tv.getMeasuredWidth(), tv.getMeasuredHeight());

        File cacheDir = new File(getCacheDir(), "shared_notes");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        
        String safeTitle = note.getTitle().replaceAll("[^a-zA-Z0-9.-]", "_");
        if (safeTitle.trim().isEmpty()) safeTitle = "Notnote_" + note.getId();

        try {
            if (isImage) {
                int imgWidth = tv.getMeasuredWidth() + (2 * margin);
                int imgHeight = Math.max(tv.getMeasuredHeight() + (2 * margin), 100);
                
                Bitmap bitmap = Bitmap.createBitmap(imgWidth, imgHeight, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                canvas.drawColor(Color.WHITE); 
                
                canvas.save();
                canvas.translate(margin, margin); 
                tv.draw(canvas);
                canvas.restore();

                File file = new File(cacheDir, safeTitle + ".jpg");
                FileOutputStream fos = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos); 
                fos.close();

                shareFile(file, "image/jpeg");
            } else {
                PdfDocument document = new PdfDocument();
                Layout layout = tv.getLayout();
                
                if (layout != null) {
                    int totalLines = layout.getLineCount();
                    int currentLine = 0;
                    int pageNum = 1;

                    while (currentLine < totalLines) {
                        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create();
                        PdfDocument.Page page = document.startPage(pageInfo);
                        Canvas canvas = page.getCanvas();
                        canvas.drawColor(Color.WHITE);
                        
                        int startY = layout.getLineTop(currentLine);
                        int availableHeight = contentHeight;
                        int endLine = currentLine;
                        
                        while (endLine < totalLines && (layout.getLineBottom(endLine) - startY) <= availableHeight) {
                            endLine++;
                        }
                        if (endLine == currentLine) endLine++; 
                        
                        int endY = endLine < totalLines ? layout.getLineTop(endLine) : layout.getLineBottom(endLine - 1);
                        
                        canvas.save();
                        canvas.translate(margin, margin - startY); 
                        canvas.clipRect(0, startY, contentWidth, endY);
                        
                        tv.draw(canvas);
                        canvas.restore();
                        
                        document.finishPage(page);
                        currentLine = endLine;
                        pageNum++;
                    }
                }

                if (isShare) {
                    File file = new File(cacheDir, safeTitle + ".pdf");
                    FileOutputStream fos = new FileOutputStream(file);
                    document.writeTo(fos);
                    fos.close();
                    document.close();
                    
                    shareFile(file, "application/pdf");
                } else {
                    File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!downloadsDir.exists()) downloadsDir.mkdirs();

                    String baseName = safeTitle;
                    File file = new File(downloadsDir, baseName + ".pdf");
                    int counter = 1;
                    while (file.exists()) {
                        file = new File(downloadsDir, baseName + " (" + counter + ").pdf");
                        counter++;
                    }

                    FileOutputStream fos = new FileOutputStream(file);
                    document.writeTo(fos);
                    fos.close();
                    document.close();

                    try {
                        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                        if (downloadManager != null) {
                            downloadManager.addCompletedDownload(
                                    file.getName(),
                                    "Downloaded successfully.",
                                    true,
                                    "application/pdf",
                                    file.getAbsolutePath(),
                                    file.length(),
                                    true 
                            );
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(this, "PDF Downloaded: " + file.getName(), Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error generating file", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareFile(File file, String mimeType) {
        try {
            Uri uri = FileProvider.getUriForFile(this, "com.santoshdev.notnote.provider", file);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mimeType);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Share Document"));
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Share Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
