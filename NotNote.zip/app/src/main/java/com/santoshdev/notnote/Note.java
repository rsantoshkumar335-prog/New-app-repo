package com.santoshdev.notnote;

public class Note {
    private int id;
    private String title;
    private String content;
    private long timestamp;
    private boolean isPrivate;
    private String pageColor; // Naya variable color ke liye

    public Note(int id, String title, String content, long timestamp, boolean isPrivate, String pageColor) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.timestamp = timestamp;
        this.isPrivate = isPrivate;
        this.pageColor = pageColor;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public long getTimestamp() { return timestamp; }
    public boolean isPrivate() { return isPrivate; }
    public String getPageColor() { return pageColor; } 

    public void setPageColor(String pageColor) { this.pageColor = pageColor; }
}
