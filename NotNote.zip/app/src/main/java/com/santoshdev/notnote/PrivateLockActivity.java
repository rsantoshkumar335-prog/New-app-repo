package com.santoshdev.notnote;

import android.app.Activity;
import android.content.Intent;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class PrivateLockActivity extends Activity {

    private ImageView btnBackLock;
    private LinearLayout btnUnlockFingerprint;
    private CancellationSignal cancellationSignal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_lock);

        btnBackLock = findViewById(R.id.btn_back_lock);
        btnUnlockFingerprint = findViewById(R.id.btn_unlock_fingerprint);

        btnBackLock.setOnClickListener(v -> finish());

        // YAHAN SE HATA DIYA HAI: Pehle 'showBiometricPrompt();' yahan tha jo directly open kar deta tha.
        // Ab page khulte hi popup nahi aayega, sirf aapka UI dikhega.

        // Ab sirf button click karne par hi khulega
        btnUnlockFingerprint.setOnClickListener(v -> {
            showBiometricPrompt();
        });
    }

    private void showBiometricPrompt() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this)
                    .setTitle("Unlock Private Vault")
                    .setSubtitle("Use your fingerprint to access hidden notes")
                    .setNegativeButton("Cancel", getMainExecutor(), (dialogInterface, i) -> {
                        Toast.makeText(PrivateLockActivity.this, "Action Cancelled", Toast.LENGTH_SHORT).show();
                    });

            BiometricPrompt biometricPrompt = builder.build();
            cancellationSignal = new CancellationSignal();

            biometricPrompt.authenticate(cancellationSignal, getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    // Agar user cancel kar de ya error aaye
                }

                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    // Success hone par Vault page kholo
                    startActivity(new Intent(PrivateLockActivity.this, PrivateNotesActivity.class));
                    finish();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    Toast.makeText(PrivateLockActivity.this, "Authentication failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "Biometric authentication not supported on this device version.", Toast.LENGTH_LONG).show();
        }
    }
}
